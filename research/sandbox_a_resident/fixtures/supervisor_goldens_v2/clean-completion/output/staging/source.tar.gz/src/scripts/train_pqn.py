#!/usr/bin/env python3
"""CLI wrapper around :class:`~src.training.pqn_trainer.PQNTrainer` (blueprint P3).

PQN is synchronous Q(lambda) on vectorized envs — **no replay buffer, no target
network, no PER** (see :mod:`src.training.pqn_trainer`). This script is the
thin operational surface over that trainer: it maps CLI flags (and an optional
YAML ``--config``) onto a :class:`~src.training.pqn_trainer.PQNConfig`, runs the
update loop while printing a periodic learning curve, halts-and-flags on a
tripwire (NaN/inf, max|Q| blow-up, action collapse), and writes a raster
checkpoint (obs_spec ``raster31v2``, algo ``pqn``) that
:meth:`~src.model.inference_agent.InferenceAgent.from_checkpoint` reloads and
``tournament_eval --engine simd`` can gate.

Examples:
    # Local learning smoke (CPU, tiny): 32 envs x 6 snakes, 800 updates
    SNAKE_DQN_DEVICE=cpu ./venv/bin/python src/scripts/train_pqn.py \\
        --total-steps 150000 --envs 32 --snakes 6 --rollout-len 24 \\
        --out-dir /tmp/pqn_smoke --eps-decay-steps 120000

    # Serious local run (a few hours on CPU / minutes on CUDA)
    ./venv/bin/python src/scripts/train_pqn.py \\
        --total-steps 5000000 --envs 64 --snakes 6 --out-dir runs/pqn_local

    # No self-play (hero-only rollouts, useful for isolating the learner)
    ./venv/bin/python src/scripts/train_pqn.py --no-self-play --total-steps 100000

    # Resume a preempted spot run (same out-dir; --total-steps is the same target)
    ./venv/bin/python src/scripts/train_pqn.py \\
        --total-steps 5000000 --out-dir runs/pqn_local \\
        --resume runs/pqn_local/latest_pqn.pth

``--total-steps`` counts HERO agent-steps (transitions the learner trains on),
matching the trainer's ``agent_steps`` odometer and the ε schedule — the loop
runs updates until that budget is met. ``--resume`` restores that odometer, so
the budget is a TARGET rather than a per-invocation delta: a resumed run trains
until the same total, and the ε ladder picks up where it left off.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import time
import uuid
from dataclasses import asdict, fields
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import torch

sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from src.core.config_loader import load_config  # noqa: E402
from src.core.device_manager import DeviceManager  # noqa: E402
from src.core.runtime_contract import (  # noqa: E402
    EffectiveWorldConfig,
    RunProvenance,
    RuntimeModeContract,
    canonical_digest,
    validate_model_head_contract,
)
from src.core.seeding import initialize_run_seed  # noqa: E402
from src.model.obs_spec import (  # noqa: E402
    OBS_SPEC_KEY,
    RASTER31V2,
    RASTER31V2_SHAPES,
    RASTER31V3,
    RASTER31V3_CONTRACT,
)
from src.training.checkpoint_contract import validate_checkpoint_contract  # noqa: E402
from src.training.pqn_lifecycle import (  # noqa: E402
    build_pqn_episode_lifecycle_contract,
    validate_pqn_episode_lifecycle_metadata,
)
from src.training.pqn_trainer import (  # noqa: E402
    PQNConfig,
    PQNPerEnvTelemetry,
    PQNSoloTelemetry,
    PQNTelemetry,
    PQNTrainer,
    TripwireError,
    pqn_action_mask_contract,
    pqn_optimizer_contract,
    pqn_reward_contract,
    pqn_sampler_contract,
    pqn_target_contract,
    validate_checkpoint_numeric_state,
)

# A --config file carries a flat ``pqn:`` block plus a few shared ``game:``/
# ``rewards:`` switches, so the same mechanics-v2 config the vector pipeline uses
# also drives PQN.


def _positive_int(value: str) -> int:
    """Parse a strictly positive CLI integer for a config count."""
    parsed = int(value)
    if parsed <= 0:
        raise argparse.ArgumentTypeError("must be positive")
    return parsed


def _nonnegative_int(value: str) -> int:
    """Parse a non-negative CLI integer for an evidence count."""
    parsed = int(value)
    if parsed < 0:
        raise argparse.ArgumentTypeError("must be non-negative")
    return parsed


def _source_revision() -> str:
    """Return the concrete checkout revision, without making training depend on git."""
    try:
        return subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=Path(__file__).parents[2], text=True
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return "unavailable"


def _load_config_overrides(path: str, app_config: Any = None) -> Dict[str, Any]:
    """Read PQN overrides from a YAML config file.

    Recognized sources (later ones win):
      * a top-level ``pqn:`` mapping whose keys match :class:`PQNConfig` fields;
      * ``game.mechanics_version`` / ``game.arena_type`` (shared sim switches);
      * ``rewards.version`` -> ``reward_version``.

    The ``pqn:`` block is parsed by :class:`PQNSettingsSchema` — the same schema
    the vector loader validates it with — so values are coerced (YAML 1.1 parses
    ``lr: 5e-4`` as a *string*) and range/ordering constraints are enforced here
    rather than surfacing as a ``TypeError`` from inside torch. A key that is not
    a ``PQNConfig`` field, or a value out of range, raises ``ValidationError``.
    Sections other than ``game:``/``rewards:``/``pqn:`` are ignored, so a full
    training config can be passed without erroring on vector-only knobs.

    Args:
        path: Path to a YAML config file.

    Returns:
        A dict of ``PQNConfig`` field -> value overrides.

    Raises:
        pydantic.ValidationError: If the ``pqn:`` block has an unknown key or a
            value that violates the schema.
    """
    app = app_config or load_config(path)
    overrides: Dict[str, Any] = {}
    provided = app.provided_fields
    shared = {
        "game.width": "game_width",
        "game.height": "game_height",
        "game.segment_size": "segment_size",
        "game.wall_thickness": "wall_thickness",
        "game.initial_food": "initial_food",
        "game.max_food": "max_food",
        "game.num_snakes": "num_snakes",
        "game.max_frames": "max_frames",
        "game.min_boost_length": "min_boost_length",
        "game.boost_length_cost_frames": "boost_length_cost_frames",
        "game.frame_rate": "frame_rate",
        "game.mechanics_version": "mechanics_version",
        "game.arena_type": "arena_type",
        "rewards.version": "reward_version",
        "rewards.starvation_max_frames": "starvation_max",
        "game.max_length": "max_length",
    }
    for path_name, field in shared.items():
        if path_name in provided:
            section, name = path_name.split(".", 1)
            overrides[field] = getattr(getattr(app, section), name)
    unsupported_rewards = {
        path_name for path_name in provided if path_name.startswith("rewards.")
    } - {"rewards.version", "rewards.starvation_max_frames"}
    if unsupported_rewards:
        raise ValueError(
            "PQN does not dispatch explicitly requested reward fields: "
            + ", ".join(sorted(unsupported_rewards))
        )
    # A dedicated PQN setting is more specific than a shared game/reward
    # default.  Apply it last while retaining the single parsed AppConfig as
    # the authoritative source of all values.
    overrides.update({name: value for name, value in app.pqn.__dict__.items() if value is not None})
    return overrides


# -- resume (blueprint §4.4 spot-preemption contract) -----------------------
#: Checkpoint entries a resume needs on top of the contract metadata.
_RESUME_REQUIRED_STATE = ("dqn_state_dict", "optimizer_state_dict")
_SAMPLER_PROVENANCE_DEFAULTS = {
    "sgd_epochs": None,
    "pad_sgd_batches": False,
    "sgd_seed": None,
    "action_collapse_patience": 1,
    "action_collapse_min_samples": 0,
    "action_collapse_raw_actions": False,
}


def resume_contract(config: PQNConfig) -> Dict[str, Any]:
    """The contract-v2 values a resume checkpoint must agree with.

    Blueprint §6 scopes contract v2 to "obs spec hash, channel list, scales,
    action semantics, mechanics version, γ/λ, algo id". Everything here is
    already recorded by :meth:`PQNTrainer.checkpoint_state`, so this is a
    comparison rather than new plumbing.

    Args:
        config: The resolved config the resumed run will train under.

    Returns:
        Mapping of checkpoint-metadata key -> expected value.
    """
    contract: Dict[str, Any] = {
        OBS_SPEC_KEY: config.obs_spec,
        "algo": "pqn",
        "gamma": config.gamma,
        "lambda": config.lambda_,
        "mechanics_version": int(config.mechanics_version),
        "reward_version": int(config.reward_version),
    }
    contract.update(RASTER31V2_SHAPES.to_metadata())
    if config.obs_spec == RASTER31V3:
        contract.update(RASTER31V3_CONTRACT.to_metadata())
    return contract


def _effective_world(config: PQNConfig) -> EffectiveWorldConfig:
    """Construct the exact world descriptor used by PQN checkpoint metadata."""
    return EffectiveWorldConfig(
        width=config.game_width,
        height=config.game_height,
        segment_size=config.segment_size,
        wall_thickness=config.wall_thickness,
        arena_type=config.arena_type,
        mechanics_version=config.mechanics_version,
        num_snakes=config.num_snakes,
        max_frames=config.max_frames,
        initial_food=config.initial_food,
        max_food=config.max_food,
        min_boost_length=config.min_boost_length,
        boost_length_cost_frames=config.boost_length_cost_frames,
        frame_rate=config.frame_rate,
        max_length=config.max_length,
        starvation_max_frames=config.starvation_max,
        max_capacity=config.max_capacity,
        kill_scale=config.kill_scale,
        death_value=config.death_value,
        normalization={
            "max_frames": float(config.max_frames),
            "starvation_max": float(config.starvation_max),
            "max_length": float(config.max_length),
        },
    )


def _require_counter(checkpoint: Dict[str, Any], key: str) -> None:
    """Require a non-boolean non-negative resume odometer."""
    value = checkpoint.get(key)
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError(f"continuation requires non-negative integer {key}")


def _require_complete_descriptor(raw: object, descriptor: type, name: str) -> Dict[str, Any]:
    """Reject metadata that would acquire semantic values from dataclass defaults."""
    if not isinstance(raw, dict):
        raise ValueError(f"continuation requires {name} mapping")
    missing = sorted(field.name for field in fields(descriptor) if field.name not in raw)
    if missing:
        raise ValueError(f"continuation requires complete {name}: missing {', '.join(missing)}")
    return raw


def validate_pqn_resume_checkpoint_config(
    checkpoint: Dict[str, Any],
    config: PQNConfig,
    checkpoint_path: str = "checkpoint",
) -> None:
    """Reject a resume checkpoint whose training contract differs from ``config``.

    Resuming across a changed γ/λ, mechanics version, reward version or obs spec
    would silently continue optimizing a DIFFERENT objective from the one the
    weights were trained under — the failure this refuses to make quietly.

    Args:
        checkpoint: The loaded checkpoint mapping.
        config: The resolved config the resumed run will train under.
        checkpoint_path: Identifier used in error messages.

    Raises:
        ValueError: On any contract disagreement or missing contract metadata.
    """
    if config.recipe == "corrected-v3" and (
        config.episode_reset_mode != "batch_barrier_v1"
        or config.episode_seed_mode != "continuous_env_rng_v1"
    ):
        raise ValueError("optimizer continuation is unsupported for derived or per-environment PQN")
    lifecycle_compatibility = None
    if config.recipe == "corrected-v3":
        lifecycle = validate_pqn_episode_lifecycle_metadata(
            checkpoint, allow_corrected_v3_adapter=True
        )
        lifecycle_compatibility = lifecycle.compatibility
        expected_lifecycle = build_pqn_episode_lifecycle_contract(
            config.episode_reset_mode,
            config.episode_seed_mode,
            config.episode_completion_mode,
        )
        if lifecycle.compatibility is None and lifecycle.digest != canonical_digest(
            expected_lifecycle
        ):
            raise ValueError("continuation episode lifecycle conflicts with requested PQN mode")
        if lifecycle.compatibility is not None and (
            config.episode_reset_mode != "batch_barrier_v1"
            or config.episode_seed_mode != "continuous_env_rng_v1"
            or config.pool_admission_mode != "scheduled_v1"
        ):
            raise ValueError("adapted corrected-v3 checkpoint requires default lifecycle modes")
    validate_checkpoint_contract(
        checkpoint,
        resume_contract(config),
        checkpoint_path=checkpoint_path,
        integer_keys=(
            "mechanics_version",
            "reward_version",
            "tactical_channels",
            "tactical_size",
            "strategic_channels",
            "strategic_size",
            "scalars",
        ),
        float_keys=("gamma", "lambda"),
        str_keys=(OBS_SPEC_KEY, "algo"),
        # obs_spec is deliberately NOT required: validate_checkpoint_contract
        # backfills a missing one to 'vector61', which then mismatches raster31v2
        # with a clearer message than "missing metadata".
        required_keys=("algo", "gamma", "lambda", "mechanics_version", "reward_version"),
        error_type=ValueError,
    )
    expected_world = _effective_world(config)
    raw_world = _require_complete_descriptor(
        checkpoint.get("effective_world"), EffectiveWorldConfig, "effective_world"
    )
    try:
        recorded_world = EffectiveWorldConfig(**raw_world)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid effective_world metadata") from exc
    if checkpoint.get("effective_world_digest") != recorded_world.digest:
        raise ValueError("effective_world_digest does not match effective_world")
    if recorded_world.digest != expected_world.digest:
        raise ValueError("continuation effective_world conflicts with requested world")
    raw_runtime = _require_complete_descriptor(
        checkpoint.get("runtime_contract"), RuntimeModeContract, "runtime_contract"
    )
    try:
        recorded_runtime = RuntimeModeContract(**raw_runtime)
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid runtime_contract metadata") from exc
    if checkpoint.get("runtime_contract_digest") != recorded_runtime.digest:
        raise ValueError("runtime_contract_digest does not match runtime_contract")
    expected_runtime = RuntimeModeContract(
        "pqn_train",
        True,
        False,
        True,
        config.mechanics_version == 2 and config.num_snakes >= 3,
        "batch_episode",
    )
    if recorded_runtime != expected_runtime:
        raise ValueError("continuation runtime_contract conflicts with PQN training")
    mask = checkpoint.get("action_mask_contract")
    if not isinstance(mask, dict) or checkpoint.get(
        "action_mask_contract_digest"
    ) != canonical_digest(mask):
        raise ValueError("invalid action_mask_contract metadata")
    expected_mask = pqn_action_mask_contract(config)
    if mask != expected_mask:
        raise ValueError("continuation action_mask_contract conflicts with requested recipe")
    contract_pairs = [
        ("reward_contract", pqn_reward_contract(config)),
        ("optimizer_contract", pqn_optimizer_contract(config)),
    ]
    if lifecycle_compatibility is None:
        contract_pairs.extend(
            [
                ("target_contract", pqn_target_contract(config)),
                ("sampler_contract", pqn_sampler_contract(config)),
            ]
        )
    elif config.recipe == "corrected-v3":
        old_target = pqn_target_contract(config).copy()
        old_target["version"] = "pqn-qlambda-corrected-v3"
        old_target.pop("episode_lifecycle_contract_digest", None)
        old_sampler = pqn_sampler_contract(config).copy()
        old_sampler["version"] = "pqn-sampler-corrected-v3"
        old_sampler.pop("episode_lifecycle_contract_digest", None)
        old_sampler.pop("policy_source_contract_digest", None)
        # The adapter validates actual pre-lifecycle corrected-v3 checkpoint
        # bytes.  Its sampler descriptor predates lifecycle-sensitive
        # provenance, so project exactly its recorded meanings instead of
        # leaking new native fields into the old schema comparison.
        old_sampler["sgd_rng"] = "shared_with_rollout"
        old_sampler["pool_mutation"] = "admission_deferred_when_all_snapshots_pinned"
        old_sampler["snapshot_admission"] = "after_sgd_positive_update_index_divisible_by_interval"
        contract_pairs.extend([("target_contract", old_target), ("sampler_contract", old_sampler)])
    for name, expected in contract_pairs:
        raw = checkpoint.get(name)
        if not isinstance(raw, dict) or checkpoint.get(f"{name}_digest") != canonical_digest(raw):
            raise ValueError(f"invalid {name} metadata")
        if canonical_digest(raw) != canonical_digest(expected):
            differing = sorted(
                key
                for key in raw.keys() | expected.keys()
                if key not in raw
                or key not in expected
                or canonical_digest(raw[key]) != canonical_digest(expected[key])
            )
            raise ValueError(
                f"continuation {name} conflicts with requested semantics: {', '.join(differing)}"
            )
    model_head = validate_model_head_contract(checkpoint, require_digest=True)
    provenance = RunProvenance.from_metadata(checkpoint)
    expected_obs_digest = (
        RASTER31V3_CONTRACT.digest if config.obs_spec == RASTER31V3 else RASTER31V2
    )
    if (
        provenance.observation_digest != expected_obs_digest
        or provenance.world_digest != recorded_world.digest
        or provenance.runtime_digest != recorded_runtime.digest
        or provenance.model_head_digest != model_head.digest
        or provenance.reward_digest != checkpoint["reward_contract_digest"]
        or provenance.target_digest != checkpoint["target_contract_digest"]
        or provenance.sampler_digest != checkpoint["sampler_contract_digest"]
        or provenance.optimizer_digest != checkpoint["optimizer_contract_digest"]
    ):
        raise ValueError("run_provenance does not agree with top-level descriptors")
    for key in (
        "update_counter",
        "agent_steps",
        "action_collapse_streak",
        "action_collapse_evidence_samples",
    ):
        _require_counter(checkpoint, key)
    # Sampler fields are fit-provenance rather than inference/promotion
    # semantics, but changing any of them on resume silently changes the
    # optimizer trajectory. Missing fields predate this metadata and mean the
    # legacy defaults, preserving compatibility with older checkpoints.
    expected_sampler = {
        "sgd_epochs": config.sgd_epochs,
        "pad_sgd_batches": config.pad_sgd_batches,
        "sgd_seed": config.sgd_seed,
        "action_collapse_patience": config.action_collapse_patience,
        "action_collapse_min_samples": config.action_collapse_min_samples,
        "action_collapse_raw_actions": config.action_collapse_raw_actions,
    }
    for key, expected in expected_sampler.items():
        actual = checkpoint.get(key, _SAMPLER_PROVENANCE_DEFAULTS[key])
        if key in ("pad_sgd_batches", "action_collapse_raw_actions"):
            matches = isinstance(actual, bool) and actual is expected
        elif expected is None:
            matches = actual is None
        else:
            matches = (
                isinstance(actual, int) and not isinstance(actual, bool) and actual == expected
            )
        if not matches:
            raise ValueError(
                f"{checkpoint_path}: sampler provenance mismatch for {key}: "
                f"checkpoint={actual!r}, config={expected!r}"
            )
    for key, expected in {
        "lr": config.lr,
        "adam_eps": config.adam_eps,
        "eps_start": config.eps_start,
        "eps_end": config.eps_end,
        "eps_decay_steps": config.eps_decay_steps,
        "recipe": config.recipe,
    }.items():
        if checkpoint.get(key) != expected:
            raise ValueError(
                f"{checkpoint_path}: continuation provenance mismatch for {key}: "
                f"checkpoint={checkpoint.get(key)!r}, config={expected!r}"
            )
    optimizer_state = checkpoint.get("optimizer_state_dict")
    if not isinstance(optimizer_state, dict) or not isinstance(
        optimizer_state.get("param_groups"), list
    ):
        raise ValueError("continuation requires optimizer param_groups")
    actual_optimizer = pqn_optimizer_contract(config, optimizer_state)
    if canonical_digest(actual_optimizer) != canonical_digest(pqn_optimizer_contract(config)):
        raise ValueError("optimizer param_groups conflict with requested Adam semantics")
    if canonical_digest(actual_optimizer) != checkpoint["optimizer_contract_digest"]:
        raise ValueError("optimizer_contract disagrees with actual param_groups")


def load_pqn_resume_checkpoint(
    resume_checkpoint: Optional[str],
    config: PQNConfig,
    map_location: Any = None,
    mode: str = "continuation",
) -> Optional[Dict[str, Any]]:
    """Load and contract-check a resume checkpoint, or return ``None``.

    Called BEFORE the trainer is built so a bad ``--resume`` fails in under a
    second rather than after the sim and network are up.

    Args:
        resume_checkpoint: Path to a PQN checkpoint, or ``None``/empty to skip.
        config: The resolved config the resumed run will train under.
        map_location: ``torch.load`` map_location (usually the target device).

    Returns:
        The validated checkpoint mapping, or ``None`` when no resume was asked.

    Raises:
        FileNotFoundError: If the path does not exist.
        RuntimeError: If the payload is unreadable, is not a checkpoint dict,
            lacks the state needed to resume, or violates the contract.
    """
    if mode == "exact":
        raise RuntimeError(
            "exact PQN resume is unsupported: simulator and pool continuation is deferred"
        )
    if not resume_checkpoint:
        return None
    if mode not in {"weights-only", "continuation"}:
        raise ValueError(f"Unknown PQN resume mode {mode!r}")

    checkpoint_path = Path(resume_checkpoint).expanduser()
    if not checkpoint_path.exists():
        raise FileNotFoundError(f"Resume checkpoint not found: {resume_checkpoint}")

    try:
        checkpoint_bytes = checkpoint_path.read_bytes()
        checkpoint = torch.load(
            io.BytesIO(checkpoint_bytes), map_location=map_location, weights_only=False
        )
        if not isinstance(checkpoint, dict):
            raise ValueError(f"checkpoint payload must be a dict, got {type(checkpoint).__name__}")
        # This private loader annotation becomes auditable output metadata on
        # the next checkpoint; it never participates in the resume contract.
        checkpoint["_p1_parent_hash"] = hashlib.sha256(checkpoint_bytes).hexdigest()
        required_state = ("dqn_state_dict",) if mode == "weights-only" else _RESUME_REQUIRED_STATE
        for key in required_state:
            if key not in checkpoint:
                raise KeyError(key)
        if mode == "continuation":
            validate_pqn_resume_checkpoint_config(
                checkpoint, config, checkpoint_path=str(checkpoint_path)
            )
            required_provenance = (
                "recipe",
                "effective_world",
                "effective_world_digest",
                "runtime_contract",
                "runtime_contract_digest",
                "action_mask_contract",
                "action_mask_contract_digest",
                "run_provenance",
                "run_provenance_digest",
                "lr",
                "adam_eps",
                "eps_start",
                "eps_end",
                "eps_decay_steps",
            )
            for key in required_provenance:
                if key not in checkpoint:
                    raise KeyError(f"continuation requires training provenance {key}")
    except (OSError, RuntimeError, EOFError, KeyError, ValueError) as e:
        raise RuntimeError(f"Failed to load resume checkpoint {checkpoint_path}: {e}") from e

    return checkpoint


def apply_resume_checkpoint(
    trainer: PQNTrainer, checkpoint: Dict[str, Any], mode: str = "continuation"
) -> None:
    """Restore weights, optimizer state and both odometers onto ``trainer``.

    Restoring ``agent_steps`` is load-bearing, not bookkeeping: the ε ladder is
    derived from it (:meth:`PQNTrainer.epsilon`), so a resume that only reloaded
    weights would snap exploration back to ``eps_start`` and re-randomize a
    converged policy. ``update_counter`` likewise drives the self-play pool's
    snapshot cadence.

    Args:
        trainer: A freshly built trainer to restore onto.
        checkpoint: A checkpoint already validated by
            :func:`load_pqn_resume_checkpoint`.
    """
    if mode not in {"weights-only", "continuation"}:
        raise ValueError(f"Cannot apply resume mode {mode!r}")
    if (
        trainer.update_idx != 0
        or trainer.agent_steps != 0
        or bool(trainer.optimizer.state)
        or bool((trainer.sim.frame != 0).any())
        or len(trainer.pool) != 0
        or trainer._episode_policy_ids is not None
        or trainer._episode_lease is not None
        or bool(trainer._episode_finished_env.any())
        or bool(trainer._episode_ids.any())
        or trainer._episode_reset_count != 0
        or trainer.last_telemetry is not None
        or trainer._initial_rng_identity
        != (
            canonical_digest(trainer.rng.bit_generator.state),
            canonical_digest(trainer.sgd_rng.bit_generator.state),
        )
        or (
            trainer._initial_action_rng_identities is not None
            and (
                trainer._action_rngs is None
                or {
                    env: canonical_digest(generator.bit_generator.state)
                    for env, generator in trainer._action_rngs.items()
                }
                != trainer._initial_action_rng_identities
            )
        )
    ):
        raise ValueError("resume requires a fresh trainer with pristine runtime state")
    validate_checkpoint_numeric_state(checkpoint)
    trainer.network.load_state_dict(checkpoint["dqn_state_dict"])
    if mode == "weights-only":
        trainer.refresh_numeric_recovery_state()
        trainer.update_idx = 0
        trainer.agent_steps = 0
        trainer._action_collapse_streak = 0
        trainer._action_collapse_evidence_samples = 0
        trainer._action_collapse_raw_action_mode = None
        trainer._resume_mode = "weights-only"
        trainer._resume_state = {
            "environment": "fresh",
            "pool": "fresh",
            "rng": "fresh",
            "parent_hash": checkpoint.get("_p1_parent_hash", "unknown"),
        }
        return
    if mode != "continuation":
        raise ValueError(f"Cannot apply resume mode {mode!r}")
    trainer.optimizer.load_state_dict(checkpoint["optimizer_state_dict"])
    trainer.refresh_numeric_recovery_state()
    trainer.update_idx = int(checkpoint.get("update_counter", 0))
    trainer.agent_steps = int(checkpoint.get("agent_steps", 0))
    trainer._action_collapse_streak = int(checkpoint.get("action_collapse_streak", 0))
    trainer._action_collapse_evidence_samples = int(
        checkpoint.get("action_collapse_evidence_samples", 0)
    )
    raw_mode = checkpoint.get("action_collapse_raw_action_mode")
    trainer._action_collapse_raw_action_mode = None if raw_mode is None else int(raw_mode)
    trainer._resume_mode = "continuation"
    trainer._resume_state = {
        "environment": "fresh",
        "pool": "fresh",
        "rng": "fresh",
        "optimizer": "restored",
        "odometer": "restored",
        "parent_hash": checkpoint.get("_p1_parent_hash", "unknown"),
    }


def build_config(args: argparse.Namespace) -> PQNConfig:
    """Merge defaults, an optional YAML ``--config``, and CLI flags into a config.

    Precedence (low -> high): :class:`PQNConfig` defaults, then the ``--config``
    file, then any explicitly-passed CLI flag. CLI flags that were left at their
    sentinel ``None`` do not override the config/defaults.

    Args:
        args: Parsed CLI namespace.

    Returns:
        The resolved :class:`PQNConfig`.
    """
    defaults = PQNConfig()
    cfg_kwargs: Dict[str, Any] = {
        key: value
        for key, value in defaults.__dict__.items()
        if key not in {"field_sources", "source_revision", "requested_device", "effective_device"}
    }
    sources = {key: "default" for key in cfg_kwargs}
    # The opt-in completion field must not perturb historical default CLI
    # checkpoint metadata. The dataclass still supplies the compatibility value.
    sources.pop("episode_completion_mode")
    sources.update(
        source_revision="checkout", requested_device="default", effective_device="runtime"
    )
    if args.config:
        app_config = load_config(args.config)
        config_values = _load_config_overrides(args.config, app_config)
        cfg_kwargs.update(config_values)
        sources.update({key: "config" for key in config_values})
        # ConfigSchema already validated the hardware section in this one read.
        cfg_kwargs["requested_device"] = app_config.hardware.device
        sources["requested_device"] = "config"

    # Map CLI flags (only those explicitly provided) onto config fields.
    cli_map = {
        "num_envs": args.envs,
        "num_snakes": args.snakes,
        "rollout_len": args.rollout_len,
        "gamma": args.gamma,
        "lambda_": args.lambda_,
        "lr": args.lr,
        "minibatches": args.minibatches,
        "minibatch_size": args.minibatch_size,
        "sgd_epochs": args.sgd_epochs,
        "pad_sgd_batches": args.pad_sgd_batches,
        "sgd_seed": args.sgd_seed,
        "action_collapse_patience": args.action_collapse_patience,
        "action_collapse_min_samples": args.action_collapse_min_samples,
        "action_collapse_raw_actions": args.action_collapse_raw_actions,
        "eps_start": args.eps_start,
        "eps_end": args.eps_end,
        "eps_decay_steps": args.eps_decay_steps,
        "hero_frac": args.hero_frac,
        "pool_capacity": args.pool_capacity,
        "pool_add_interval": args.pool_add_interval,
        "flip_augment": args.flip_augment,
        "max_abs_q_alarm": args.max_abs_q_alarm,
        "seed": args.seed,
        "arena_type": args.arena_type,
        "mechanics_version": args.mechanics_version,
        "profile": args.profile or None,
        "kill_scale": args.kill_scale,
        "death_value": args.death_value,
        "living_mass_reward_coefficient": getattr(args, "living_mass_reward_coefficient", None),
        "episode_reset_mode": args.episode_reset_mode,
        "episode_seed_mode": args.episode_seed_mode,
        "pool_admission_mode": args.pool_admission_mode,
        "decision_phase_mode": args.decision_phase_mode,
        "episode_completion_mode": args.episode_completion_mode,
    }
    for key, value in cli_map.items():
        if value is not None:
            cfg_kwargs[key] = value
            sources[key] = "cli"

    # --no-self-play collapses the opponent pool and forces every slot to hero.
    if args.no_self_play:
        cfg_kwargs["pool_capacity"] = 0
        cfg_kwargs["hero_frac"] = 1.0
        sources["pool_capacity"] = sources["hero_frac"] = "cli"

    if cfg_kwargs.get("recipe") == "corrected-v3":
        # Recipe selection is explicit; omitted shared AppConfig values never
        # leak their legacy v1 defaults into this corrected training world.
        recipe_values = {
            "obs_spec": "raster31v3",
            "mechanics_version": 2,
            "reward_version": 2,
            "arena_type": "rectangular",
            "flip_augment": False,
        }
        for field, expected in recipe_values.items():
            if sources.get(field) != "default" and cfg_kwargs[field] != expected:
                raise ValueError(
                    f"corrected-v3 recipe conflicts with explicit {field}={cfg_kwargs[field]!r}"
                )
            if sources.get(field) == "default":
                cfg_kwargs[field] = expected
                sources[field] = "recipe"

    cfg_kwargs["field_sources"] = sources
    cfg_kwargs["source_revision"] = _source_revision()

    return PQNConfig(**cfg_kwargs)


def _resolve_device(name: Optional[str]) -> torch.device:
    """Resolve a device string, honoring the :class:`DeviceManager` default.

    Args:
        name: ``"cpu"``/``"cuda"``/``"mps"`` or ``None`` for auto-select.

    Returns:
        The chosen :class:`torch.device`.
    """
    if name:
        device = torch.device(name)
        DeviceManager.override_device(device)
        return device
    return DeviceManager.get_device()


def _format_row(tel: PQNTelemetry) -> str:
    """One-line telemetry summary for the live learning curve."""
    return (
        f"upd {tel.update:>5} | steps {tel.agent_steps:>10,} | "
        f"eps {tel.epsilon:5.3f} | loss {tel.loss:9.4f} | "
        f"|Q|~ {tel.mean_abs_q:7.3f} max {tel.max_abs_q:8.3f} | "
        f"gnorm {tel.grad_norm:7.3f} | R/step {tel.mean_reward:+7.4f} | "
        f"base {tel.mean_base_reward:+7.4f} mass {tel.mean_living_mass_reward:+7.4f} | "
        f"H {tel.action_entropy:5.3f} | hero K/D {tel.hero_kills}/{tel.hero_deaths} | "
        f"completed {tel.completed_episodes} | "
        f"boost {100 * tel.boost_fraction:4.1f}% | pool {tel.pool_size} | "
        f"sgd {tel.sampled_transition_draws}/{tel.eligible_hero_transitions} "
        f"({tel.unique_sampled_transitions} unique, {tel.optimizer_steps} steps) | "
        f"Hraw {tel.raw_action_entropy:5.3f} mode {tel.raw_action_mode} "
        f"collapse {tel.action_collapse_streak}/{tel.action_collapse_evidence_samples}"
    )


def _telemetry_record(tel: PQNTelemetry) -> Dict[str, Any]:
    """A JSON-serializable dict of a telemetry snapshot (for the history file)."""
    record = {
        "update": tel.update,
        "agent_steps": tel.agent_steps,
        "epsilon": tel.epsilon,
        "loss": tel.loss,
        "grad_norm": tel.grad_norm,
        "mean_abs_q": tel.mean_abs_q,
        "max_abs_q": tel.max_abs_q,
        "mean_reward": tel.mean_reward,
        "mean_base_reward": tel.mean_base_reward,
        "mean_living_mass_reward": tel.mean_living_mass_reward,
        "mean_total_reward": tel.mean_total_reward,
        "action_entropy": tel.action_entropy,
        "legacy_kills_per_rollout": tel.legacy_kills_per_rollout,
        "boost_fraction": tel.boost_fraction,
        "pool_size": tel.pool_size,
        "eligible_hero_transitions": tel.eligible_hero_transitions,
        "sampled_transition_draws": tel.sampled_transition_draws,
        "unique_sampled_transitions": tel.unique_sampled_transitions,
        "optimizer_steps": tel.optimizer_steps,
        "valid_slot_fraction": tel.valid_slot_fraction,
        "raw_action_entropy": tel.raw_action_entropy,
        "raw_action_mode": tel.raw_action_mode,
        "action_collapse_streak": tel.action_collapse_streak,
        "action_collapse_evidence_samples": tel.action_collapse_evidence_samples,
        "hero_kills": tel.hero_kills,
        "hero_deaths": tel.hero_deaths,
        "hero_food_contact_events": tel.hero_food_contact_events,
        "completed_episodes": tel.completed_episodes,
        "valid_transitions": tel.valid_transitions,
        "rollout_capacity": tel.rollout_capacity,
        "hero_eligible_fraction": tel.hero_eligible_fraction,
        "policy_exposure": tel.policy_exposure or {},
        "raw_action_counts": tel.raw_action_counts or [0, 0, 0, 0, 0, 0],
        "episode_reset_count": tel.episode_reset_count,
    }
    if isinstance(tel, PQNPerEnvTelemetry):
        record.update(
            {
                "episode_reset_mode": tel.episode_reset_mode,
                "episode_seed_mode": tel.episode_seed_mode,
                "episode_ids": tel.episode_ids or [],
                "episode_reset_counts": tel.episode_reset_counts or [],
                "reset_env_indices": tel.reset_env_indices or [],
                "episode_world_seeds": tel.episode_world_seeds or [],
                "episode_policy_ids": tel.episode_policy_ids or [],
                "episode_policy_identities": tel.episode_policy_identities or {},
            }
        )
    if isinstance(tel, PQNSoloTelemetry):
        record["episode_completion_mode"] = tel.episode_completion_mode
    return record


def _sha256_file(path: Path) -> str:
    """Return the digest of an already-durable checkpoint artifact."""
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


class _CheckpointArchive:
    """Immutable copies of accepted rolling checkpoints for one invocation.

    The trainer owns the native checkpoint contract and its atomic writer.  This
    operational wrapper either writes the start state directly to its immutable
    destination or replaces ``latest_pqn.pth`` through the trainer's writer and
    then copies that completed artifact into a freshly allocated run directory.
    Archive copies are published create-only, so an interrupted copy is never a
    visible checkpoint and later rolling-checkpoint replacements cannot mutate
    an archive entry.
    """

    def __init__(self, out_dir: Path, latest_path: Path) -> None:
        root = out_dir / "checkpoints"
        root.mkdir(parents=True, exist_ok=True)
        # ``uuid4`` makes each invocation distinct even for rapid resumes in the
        # same output directory. mkdir(exist_ok=False) keeps an accidental
        # collision from overwriting prior evidence.
        self.directory = root / f"run_{time.time_ns()}_{os.getpid()}_{uuid.uuid4().hex}"
        self.directory.mkdir(exist_ok=False)
        self.latest_path = latest_path
        self.manifest_path = self.directory / "events.jsonl"
        self._events: List[Dict[str, Any]] = []

    @staticmethod
    def _publish_temporary(temporary: Path, destination: Path) -> None:
        """Publish a same-directory temporary file without replacing evidence."""
        # ``link`` is create-only. The source is an archive-local temporary,
        # rather than latest, so this never aliases the mutable rolling file.
        os.link(temporary, destination)

    def _write_manifest(self, events: Sequence[Dict[str, Any]]) -> None:
        """Atomically replace the JSONL receipt with a complete event sequence."""
        temporary = self.directory / f".{self.manifest_path.name}.{uuid.uuid4().hex}.tmp"
        try:
            with temporary.open("w", encoding="utf-8") as manifest_fh:
                for event in events:
                    manifest_fh.write(json.dumps(event, sort_keys=True) + "\n")
                manifest_fh.flush()
                os.fsync(manifest_fh.fileno())
            # Manifest replacement is intentionally allowed: it is a complete
            # prefix snapshot, so a crash leaves either the old valid prefix or
            # the new valid sequence, never a torn JSONL line.
            os.replace(temporary, self.manifest_path)
        finally:
            temporary.unlink(missing_ok=True)

    def _copy_latest_create_only(self, destination: Path) -> None:
        """Copy the rolling checkpoint without exposing a partial archive file."""
        temporary = self.directory / f".{destination.name}.{uuid.uuid4().hex}.tmp"
        try:
            shutil.copyfile(self.latest_path, temporary)
            with temporary.open("rb") as temporary_fh:
                os.fsync(temporary_fh.fileno())
            # Linking the temporary copy (never ``latest`` itself) publishes
            # only a complete file and fails if a destination somehow exists.
            self._publish_temporary(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def _save_start_create_only(self, trainer: PQNTrainer, destination: Path) -> None:
        """Serialize start state without creating or replacing the rolling file."""
        temporary = self.directory / f".{destination.name}.{uuid.uuid4().hex}.tmp"
        try:
            trainer.save_checkpoint(str(temporary))
            self._publish_temporary(temporary, destination)
        finally:
            temporary.unlink(missing_ok=True)

    def save(self, trainer: PQNTrainer, label: str, *, replace_latest: bool) -> Path:
        """Save one accepted state and append its immutable evidence receipt."""
        update_idx = int(trainer.update_idx)
        agent_steps = int(trainer.agent_steps)
        destination = self.directory / (
            f"{label}_update_{update_idx:08d}_steps_{agent_steps:012d}.pth"
        )
        published = False
        try:
            if replace_latest:
                trainer.save_checkpoint(str(self.latest_path))
                # The trainer's atomic writer has completed before this copy begins.
                self._copy_latest_create_only(destination)
            else:
                # Start is evidence for this invocation only. It must not create or
                # replace latest: a first-update tripwire retains the old contract.
                self._save_start_create_only(trainer, destination)
            published = True
            event = {
                "label": label,
                "update_idx": update_idx,
                "agent_steps": agent_steps,
                "checkpoint_path": destination.name,
                "sha256": _sha256_file(destination),
                "created_at_unix_ns": time.time_ns(),
            }
            candidate_events = [*self._events, event]
            self._write_manifest(candidate_events)
        except BaseException:
            if published:
                destination.unlink(missing_ok=True)
            raise
        self._events = candidate_events
        return destination


def train_loop(
    trainer: PQNTrainer,
    total_steps: int,
    log_every: int,
    ckpt_every: int,
    out_dir: Path,
    append_history: bool = False,
    archive_checkpoints: bool = False,
) -> Tuple[List[PQNTelemetry], Optional[str]]:
    """Run updates until ``total_steps`` hero agent-steps are reached.

    Prints a telemetry row every ``log_every`` updates, snapshots a checkpoint
    every ``ckpt_every`` updates (and at clean completion), and writes the full
    telemetry history to ``out_dir/history.jsonl``. A :class:`TripwireError`
    halts the loop without replacing ``latest_pqn.pth``. Every tripwire gets a
    durable JSON incident; finite diagnostic alarms additionally get a labelled
    incident checkpoint rather than silently becoming the latest model.

    ``total_steps`` is compared against the trainer's odometer, so a resumed
    trainer counts its restored steps toward the same target.

    Args:
        trainer: The configured :class:`PQNTrainer`.
        total_steps: Target hero agent-step budget.
        log_every: Print cadence (updates).
        ckpt_every: Checkpoint cadence (updates); ``0`` disables periodic saves.
        out_dir: Directory for checkpoints and the history file.
        append_history: Append to an existing ``history.jsonl`` instead of
            truncating it — set when resuming, so a preemption does not erase the
            telemetry of the run being continued.
        archive_checkpoints: Save immutable start, periodic, and clean-final
            copies under a unique ``checkpoints/run_*`` invocation directory.

    Returns:
        ``(history, tripped)``: the telemetry list collected before the
        budget/tripwire ended the loop, and the tripwire message (``None`` on a
        clean finish).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    history_path = out_dir / "history.jsonl"
    latest_path = out_dir / "latest_pqn.pth"
    incidents_dir = out_dir / "incidents"
    archive = _CheckpointArchive(out_dir, latest_path) if archive_checkpoints else None

    history: List[PQNTelemetry] = []
    start = time.time()
    # Steps/s must measure THIS session's work: a resumed trainer starts with a
    # non-zero odometer that was earned before this process existed.
    start_steps = trainer.agent_steps
    tripped: Optional[str] = None

    # This is intentionally after resume restoration (performed by ``main``)
    # and before the first update. It describes the exact state this invocation
    # began from, whether that state is freshly initialized or resumed.
    if archive is not None:
        archive.save(trainer, "start", replace_latest=False)

    with history_path.open("a" if append_history else "w", encoding="utf-8") as hist_fh:
        while trainer.agent_steps < total_steps:
            try:
                tel = trainer.update()
            except TripwireError as exc:
                tripped = str(exc)
                incident_id = f"update_{trainer.update_idx:08d}_{exc.incident_class}"
                incident_path = incidents_dir / f"{incident_id}.json"
                incidents_dir.mkdir(parents=True, exist_ok=True)
                telemetry = exc.telemetry
                incident_record = {
                    "class": exc.incident_class,
                    "message": str(exc),
                    "telemetry": None if telemetry is None else _telemetry_record(telemetry),
                    "details": exc.incident,
                    "trainer_state": {
                        "update_idx": trainer.update_idx,
                        "agent_steps": trainer.agent_steps,
                    },
                    "numeric_recovery": trainer.numeric_recovery_metadata(),
                }
                with incident_path.open("w", encoding="utf-8") as incident_fh:
                    json.dump(incident_record, incident_fh, sort_keys=True)
                    incident_fh.write("\n")
                    incident_fh.flush()
                if exc.is_finite_alarm:
                    trainer.save_incident_checkpoint(str(incidents_dir / f"{incident_id}.pth"), exc)
                print(f"\n[TRIPWIRE] halting: {exc}", file=sys.stderr)
                break

            history.append(tel)
            hist_fh.write(json.dumps(_telemetry_record(tel)) + "\n")
            hist_fh.flush()

            if tel.update % log_every == 0:
                elapsed = time.time() - start
                sps = (tel.agent_steps - start_steps) / elapsed if elapsed > 0 else 0.0
                print(f"{_format_row(tel)} | {sps:,.0f} steps/s")

            if ckpt_every and tel.update > 0 and tel.update % ckpt_every == 0:
                if archive is None:
                    trainer.save_checkpoint(str(latest_path))
                else:
                    archive.save(trainer, "cadence", replace_latest=True)

    if not tripped:
        if archive is None:
            trainer.save_checkpoint(str(latest_path))
        else:
            archive.save(trainer, "final", replace_latest=True)
    elapsed = time.time() - start
    session_steps = trainer.agent_steps - start_steps
    print(
        f"\n[train_pqn] done: {len(history)} updates, "
        f"{session_steps:,} agent-steps this session "
        f"({trainer.agent_steps:,} total) in {elapsed:.1f}s "
        f"({session_steps / elapsed if elapsed > 0 else 0.0:,.0f} steps/s)"
    )
    if latest_path.exists():
        print(f"[train_pqn] checkpoint: {latest_path}")
    else:
        print("[train_pqn] checkpoint: absent (no accepted finite state)")
    if tripped:
        print(f"[train_pqn] FLAGGED (tripwire): {tripped}", file=sys.stderr)

    return history, tripped


def _print_curve_summary(history: Sequence[PQNTelemetry]) -> None:
    """Print a compact start-vs-end learning-curve summary."""
    if not history:
        print("[train_pqn] no updates completed.")
        return
    head = history[: max(1, len(history) // 10)]
    tail = history[-max(1, len(history) // 10) :]

    def _avg(rows: Sequence[PQNTelemetry], attr: str) -> float:
        return sum(getattr(r, attr) for r in rows) / len(rows)

    print("\n[train_pqn] learning-curve summary (first 10% -> last 10%):")
    for attr, label in (
        ("loss", "loss"),
        ("mean_reward", "reward/step"),
        ("mean_abs_q", "mean|Q|"),
        ("action_entropy", "entropy"),
        ("hero_kills", "hero kills/rollout"),
        ("boost_fraction", "boost frac"),
    ):
        print(f"  {label:>14}: {_avg(head, attr):+.4f}  ->  {_avg(tail, attr):+.4f}")


def main(argv: Optional[Sequence[str]] = None) -> int:
    """Parse args, build the trainer, run the loop, and save a checkpoint.

    Args:
        argv: Optional argument vector (defaults to ``sys.argv``).

    Returns:
        Process exit code: ``0`` on a clean run, ``2`` if a tripwire fired.
    """
    p = argparse.ArgumentParser(
        description="Train the dual-scale raster network with PQN Q(lambda) (blueprint P3).",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument(
        "--total-steps",
        type=int,
        default=100_000,
        help="Target HERO agent-steps (transitions trained on).",
    )
    p.add_argument("--out-dir", default="runs/pqn", help="Directory for checkpoints + history.")
    p.add_argument("--config", default=None, help="Optional YAML config with a pqn: block.")
    p.add_argument("--device", default=None, help="cpu / cuda / mps (default: auto-select).")
    p.add_argument(
        "--resume",
        default=None,
        help=(
            "Resume from a PQN checkpoint (e.g. OUT_DIR/latest_pqn.pth) after a spot "
            "preemption: restores weights, optimizer state and the agent-step/update "
            "odometers, appends to history.jsonl, and refuses a checkpoint whose "
            "gamma/lambda/mechanics/reward/obs_spec contract differs from this config."
        ),
    )
    p.add_argument(
        "--resume-mode",
        choices=("weights-only", "continuation", "exact"),
        default="continuation",
        help=(
            "weights-only resets training state; continuation restores optimizer/odometers; "
            "exact is rejected."
        ),
    )

    # Sim shape.
    p.add_argument("--envs", type=int, default=None, help="E parallel envs.")
    p.add_argument("--snakes", type=int, default=None, help="S snakes per env.")
    p.add_argument("--rollout-len", type=int, default=None, help="T steps per update.")

    # Optimization / algorithm.
    p.add_argument("--gamma", type=float, default=None)
    p.add_argument("--lambda", dest="lambda_", type=float, default=None)
    p.add_argument("--lr", type=float, default=None)
    p.add_argument("--minibatches", type=int, default=None)
    p.add_argument("--minibatch-size", type=int, default=None)
    p.add_argument(
        "--sgd-epochs",
        type=_positive_int,
        default=None,
        help="Exact-coverage SGD epochs (default: legacy fixed-minibatch sampler).",
    )
    p.add_argument(
        "--pad-sgd-batches",
        action="store_const",
        const=True,
        default=None,
        help="Pad undersized SGD forwards to minibatch-size, then discard padded predictions.",
    )
    p.add_argument("--sgd-seed", type=int, default=None, help="Optional independent SGD RNG seed.")
    p.add_argument(
        "--action-collapse-patience",
        type=_positive_int,
        default=None,
        help="Consecutive low-entropy updates required before stopping.",
    )
    p.add_argument(
        "--action-collapse-min-samples",
        type=_nonnegative_int,
        default=None,
        help="Eligible hero samples required across a low-entropy streak.",
    )
    p.add_argument(
        "--action-collapse-raw-actions",
        action="store_const",
        const=True,
        default=None,
        help="Measure collapse from raw rollout actions before augmentation.",
    )

    # Exploration.
    p.add_argument("--eps-start", type=float, default=None)
    p.add_argument("--eps-end", type=float, default=None)
    p.add_argument("--eps-decay-steps", type=int, default=None, help="Agent-steps to decay eps.")

    # Self-play.
    p.add_argument("--hero-frac", type=float, default=None, help="P(slot is hero); blueprint 0.8.")
    p.add_argument("--pool-capacity", type=int, default=None, help="Max frozen opponents (<=10).")
    p.add_argument("--pool-add-interval", type=int, default=None, help="Add snapshot every N upd.")
    p.add_argument(
        "--no-self-play",
        action="store_true",
        help="Hero-only rollouts (pool_capacity=0, hero_frac=1.0).",
    )

    # Augmentation / tripwire / sim.
    flip = p.add_mutually_exclusive_group()
    flip.add_argument(
        "--flip-augment", dest="flip_augment", action="store_const", const=True, default=None
    )
    flip.add_argument("--no-flip-augment", dest="flip_augment", action="store_const", const=False)
    p.add_argument("--max-abs-q-alarm", type=float, default=None, help="Tripwire max|Q| threshold.")
    p.add_argument(
        "--kill-scale",
        type=float,
        default=None,
        help="Reward per victim-length for a kill (default 0.3). Sweep to probe kills-0.",
    )
    p.add_argument(
        "--death-value",
        type=float,
        default=None,
        help="Death reward AND trapped-state bootstrap value (default -3.0). Sweepable.",
    )
    p.add_argument(
        "--living-mass-reward-coefficient",
        type=float,
        default=None,
        help=(
            "Opt-in corrected-v3 base objective: beta * valid * post_alive * "
            "post_logical_length (default: disabled)."
        ),
    )
    p.add_argument(
        "--profile",
        action="store_true",
        help="Print a CUDA-synced per-phase time breakdown each update (featurize/forward/sim/targets/sgd).",  # noqa: E501
    )
    p.add_argument("--arena-type", default=None, help="rectangular / circular.")
    p.add_argument(
        "--mechanics-version", type=int, default=None, help="Sim mechanics (blueprint 2)."
    )
    p.add_argument("--seed", type=int, default=None)
    p.add_argument(
        "--episode-reset-mode",
        choices=("batch_barrier_v1", "per_env_autoreset_v1"),
        default=None,
        help="Episode reset timing (corrected-v3 experimental modes only).",
    )
    p.add_argument(
        "--episode-seed-mode",
        choices=("continuous_env_rng_v1", "derived_env_episode_v1"),
        default=None,
        help="Environment RNG lifecycle mode (corrected-v3 experimental modes only).",
    )
    p.add_argument(
        "--pool-admission-mode",
        choices=("scheduled_v1", "disabled_v1"),
        default=None,
        help="Frozen-opponent snapshot admission mode.",
    )
    p.add_argument(
        "--decision-phase-mode",
        choices=("pre_transition_v1", "watch_pre_move_v1"),
        default=None,
        help="Observation/target decision phase (corrected-v3 raster31v3 only).",
    )
    p.add_argument(
        "--episode-completion-mode",
        choices=(
            "population_floor_or_frame_cap_v1",
            "sole_snake_death_or_frame_cap_v1",
        ),
        default=None,
        help="Environment episode completion mode (solo mode is corrected-v3 Watch S1 only).",
    )

    # Logging cadence.
    p.add_argument("--log-every", type=int, default=10, help="Print a row every N updates.")
    p.add_argument(
        "--ckpt-every", type=int, default=200, help="Checkpoint every N updates (0=off)."
    )
    p.add_argument(
        "--archive-checkpoints",
        action="store_true",
        help=(
            "Keep immutable start, periodic, and clean-final checkpoint copies in a "
            "unique OUT_DIR/checkpoints/run_* directory."
        ),
    )

    args = p.parse_args(argv)

    config = build_config(args)
    seed_request = None if config.field_sources["seed"] == "default" else config.seed
    seed_context = initialize_run_seed(seed_request)
    if seed_request is None:
        config.field_sources["seed"] = "entropy"
    config.seed = seed_context.effective_seed
    # CLI > explicitly-set environment > validated YAML hardware > auto.
    yaml_device = config.requested_device if config.requested_device != "auto" else None
    requested_device = args.device or os.environ.get("SNAKE_DQN_DEVICE") or yaml_device or "auto"
    # Use the same selected winner for construction and metadata. Passing the
    # YAML choice here after an environment choice would otherwise train on MPS
    # while claiming CPU in the artifact.
    device = _resolve_device(None if requested_device == "auto" else requested_device)
    config.requested_device = requested_device
    config.field_sources["requested_device"] = (
        "cli"
        if args.device
        else "env" if os.environ.get("SNAKE_DQN_DEVICE") else "config" if yaml_device else "default"
    )
    config.effective_device = str(device)
    out_dir = Path(args.out_dir)

    print("[train_pqn] device:", device)
    print("[train_pqn] config:", json.dumps(asdict(config), indent=2, sort_keys=True))

    # Load + contract-check before building the trainer so a bad --resume fails
    # immediately rather than after the sim and network are up.
    resume_blob = load_pqn_resume_checkpoint(
        args.resume, config, map_location=device, mode=args.resume_mode
    )

    trainer = PQNTrainer(config, device=device)
    print("[train_pqn] network:", repr(trainer.network))
    print("[train_pqn] params:", f"{trainer.network.get_num_parameters()['total']:,}")

    if resume_blob is not None:
        apply_resume_checkpoint(trainer, resume_blob, mode=args.resume_mode)
        print(
            f"[train_pqn] resumed {args.resume}: update {trainer.update_idx:,}, "
            f"{trainer.agent_steps:,} agent-steps, eps {trainer.epsilon():.4f} "
            f"(target {args.total_steps:,})"
        )
        if config.pool_capacity > 0:
            print(
                "[train_pqn] WARNING: the opponent pool is not part of the checkpoint, "
                "so self-play restarts against an EMPTY pool and refills with copies of "
                "the current hero; pool diversity is reduced for roughly "
                f"{config.pool_capacity * config.pool_add_interval:,} updates.",
                file=sys.stderr,
            )

    primary_error: Optional[BaseException] = None
    try:
        history, tripped = train_loop(
            trainer,
            total_steps=args.total_steps,
            log_every=args.log_every,
            ckpt_every=args.ckpt_every,
            out_dir=out_dir,
            append_history=resume_blob is not None,
            archive_checkpoints=args.archive_checkpoints,
        )
        _print_curve_summary(history)
        if tripped:
            # A tripwire is the authoritative run classification.  Cleanup is
            # still attempted in ``finally``; a cleanup failure must not turn a
            # flagged numerical run into a successful or differently-classed one.
            return 2
        return 0
    except BaseException as exc:
        primary_error = exc
        raise
    finally:
        try:
            trainer.close()
        except BaseException as cleanup_error:
            if primary_error is not None:
                raise primary_error from cleanup_error
            if "tripped" in locals() and tripped:
                print(
                    f"[train_pqn] cleanup failed after tripwire: {cleanup_error}", file=sys.stderr
                )
                # Receipt persistence is useful secondary evidence, but a
                # full disk or permission fault here must not replace the
                # authoritative tripwire exit classification (2).
                try:
                    incidents_dir = out_dir / "incidents"
                    incidents_dir.mkdir(parents=True, exist_ok=True)
                    with (incidents_dir / "cleanup_after_tripwire.json").open(
                        "w", encoding="utf-8"
                    ) as fh:
                        json.dump(
                            {
                                "class": "tripwire_cleanup_failure",
                                "tripwire_message": tripped,
                                "cleanup_error_type": type(cleanup_error).__name__,
                                "cleanup_error": str(cleanup_error),
                            },
                            fh,
                            sort_keys=True,
                        )
                        fh.write("\n")
                except OSError as receipt_error:
                    print(
                        "[train_pqn] cleanup incident receipt failed after tripwire: "
                        f"{receipt_error}",
                        file=sys.stderr,
                    )
            else:
                raise


if __name__ == "__main__":
    raise SystemExit(main())
